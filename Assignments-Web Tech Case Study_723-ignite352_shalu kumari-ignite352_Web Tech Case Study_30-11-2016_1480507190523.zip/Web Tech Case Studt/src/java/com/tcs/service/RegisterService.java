/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.service;

import com.tcs.bean.RegisterBean;
import com.tcs.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author ignite352
 */
public class RegisterService {

    public boolean register(RegisterBean regbean) throws ClassNotFoundException, SQLException {
         String firstname=regbean.getFirstname();
         String lastname=regbean.getLastname();
         String dob=regbean.getDob();
         String gender=regbean.getGender();
         String phone=regbean.getPhone();
         String email=regbean.getEmail();
         String password=regbean.getPassword();
         String address=regbean.getAddress();
         String city=regbean.getCity();
         String state=regbean.getState();
         String postal=regbean.getPostal();
         String country=regbean.getCountry();
         
          Connection con = DBConnection.createConn();
          PreparedStatement ps=con.prepareStatement("insert into registration values (?,?,?,?,?,?,?,?,?,?,?,?)");
          ps.setString(1, firstname);
          ps.setString(2, lastname);
          ps.setString(3, dob);
          ps.setString(4, gender);
          ps.setString(5, phone);
          ps.setString(6, email);
          ps.setString(7, password);
          ps.setString(8, address);
          ps.setString(9, city);
          ps.setString(10, state);
          ps.setString(11, postal);
          ps.setString(12, country);
          
          int a=ps.executeUpdate();
        
        con.close();
        ps.close();
        
        if(a!=0)
        {
            return true;
        }
        else
        {
            return false;
        }
                
    }
}
