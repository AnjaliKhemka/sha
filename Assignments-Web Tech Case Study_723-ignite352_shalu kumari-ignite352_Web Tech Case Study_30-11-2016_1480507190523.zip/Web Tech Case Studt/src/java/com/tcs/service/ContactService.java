/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.service;

import com.tcs.bean.ContactBean;
import com.tcs.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author ignite352
 */
public class ContactService {

    public String contact(ContactBean contactbean) throws ClassNotFoundException, SQLException {
        
    String name=contactbean.getName();
    String email=contactbean.getEmail();
    String phone=contactbean.getPhone();
    String address=contactbean.getAddress();
    String message=contactbean.getMessage();
    
     
    int i;
          
        Connection con = DBConnection.createConn();
          PreparedStatement  pre = con.prepareStatement("insert into contact values (?,?,?,?,?)");
            pre.setString(1, name);
            pre.setString(2, email);
            pre.setString(3, phone);
            pre.setString(4, address);
            pre.setString(5, message);
            i = pre.executeUpdate();
        
     pre.close();
     con.close();
     if(i!=0)
     {
     return "success";
     
     }
     else
     {
     return "failure";
     }
    }
}
