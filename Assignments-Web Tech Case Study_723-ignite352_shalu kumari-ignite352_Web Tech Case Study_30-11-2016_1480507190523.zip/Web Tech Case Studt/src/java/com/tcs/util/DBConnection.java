/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.tcs.util;

import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author ignite352
 */
public class DBConnection {
 public static java.sql.Connection createConn() throws ClassNotFoundException, SQLException{
 Class.forName("com.mysql.jdbc.Driver");
  java.sql.Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/webtable", "root", "root");
        return con;   
 }

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        System.out.println(DBConnection.createConn());
           
    }
}
    

